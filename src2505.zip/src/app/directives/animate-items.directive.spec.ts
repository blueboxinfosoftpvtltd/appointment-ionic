import { AnimateItemsDirective } from './animate-items.directive';

describe('AnimateItemsDirective', () => {
  it('should create an instance', () => {
    // const directive = new AnimateItemsDirective();
    // expect(directive).toBeTruthy();
  });
});
